import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.Duration;

/*Използвайки Selenium WebDriver и TestNG, напишете автоматизиран позитивен тест, който:
1.	Отива на http://shop.pragmatic.bg;
2.	Клика върху надписа “My Account” в горния край на екрана;
3.	Клика върху надписа “Register”;
4.	Регистрира нов потребител като:
-	 попълва задължителните полета,
-	селектира задължителните чекбоксове,
-	клика върху бутона “Continue”;
5.	Потвърждава успешната регистрация на новия потребител.*/

public class RegisterNewAccount {
    WebDriver driver;

    @BeforeMethod
    public void setup() {
        driver = new ChromeDriver();
        driver.get("http://shop.pragmatic.bg");
        driver.manage().window().maximize();
    }
        @AfterMethod
        public void quitDriver() {
            driver.quit();
        }
        @Test
        public void registrationNewAccount() {
        driver.findElement(By.xpath("//i[@class ='fa fa-user']/ ..")).click();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@class='dropdown-menu dropdown-menu-right']//li[1]"))       );
        WebElement registerButton = driver.findElement(By.xpath("//ul[@class='dropdown-menu dropdown-menu-right']//li[1]"));
        registerButton.click();
        WebElement firstNameField = driver.findElement(By.id("input-firstname"));
        firstNameField.sendKeys("Andrey");
        WebElement lastNameField = driver.findElement(By.id("input-lastname"));
        lastNameField.sendKeys("Nikolov");
        String prefix = RandomStringUtils.randomAlphabetic(7);
        String sufix = RandomStringUtils.randomAlphabetic(5);
        String domain = RandomStringUtils.randomAlphabetic(3);
        String emailAddress = prefix + "@" + sufix + "." + domain;
        driver.findElement(By.id("input-email")).sendKeys(emailAddress);
        String phoneNumber = RandomStringUtils.randomNumeric(12);
        driver.findElement(By.id("input-telephone")).sendKeys(phoneNumber);
        WebElement passwordField = driver.findElement(By.id("input-password"));
        passwordField.sendKeys("parola123!");
        WebElement confirmPasswordField = driver.findElement(By.id("input-confirm"));
        confirmPasswordField.sendKeys("parola123!");
        WebElement checkAgree = driver.findElement(By.xpath("//input[@name='agree']"));
        checkAgree.click();
        driver.findElement(By.xpath("//input[@class='btn btn-primary']")).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[text()='Your Account Has Been Created!']")));
        WebElement elementAccountCreated = driver.findElement(By.xpath("//h1[text()='Your Account Has Been Created!']"));
        elementAccountCreated.getText();
        Assert.assertEquals(elementAccountCreated,elementAccountCreated);
        }
    }



